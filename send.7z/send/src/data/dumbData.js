export const OBJECT_TEST = [
    {
        name: "children-1",
        description: "is simply dummy text of the printing and typesetting industry."
    },
    {
        name: "children-2",
        description: "Lorem Ipsum has been the industry's standard dummy text ever since the 1500s"
    },
    {
        name: "children-3",
        description: "sometimes on purpose (injected humour and the like)."
    },
    {
        name: "children-4",
        description: "Various versions have evolved over the years, sometimes by accident,"
    }

]

