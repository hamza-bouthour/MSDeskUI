const Children = props => {
    return (
        <div className="col-2">
            <h4>{props.name}</h4>
            <p>{props.description}</p>
        </div>
    )
}

export default Children;